package com.kb.restart2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FoodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);


        //1. 처리할 버튼을 찾으세요.
        Button backbackbutton=findViewById(R.id.backbackbutton);

        //2. 버튼을 클릭했을때 처리할 것을 셋팅
        backbackbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //* 3. 처리할 내용은 DietActivity를 시작 *
                Toast.makeText(getApplicationContext(),"세부계획으로 가기 버튼을 누르셨군요..",Toast.LENGTH_LONG).show();

                Intent go=new Intent(getApplicationContext(),Plan5Activity.class);

                startActivity(go);


            }
        });



    }
}