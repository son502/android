package com.kb.phone04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. layout에 있던 버튼을 찾아서
        Button cal =findViewById(R.id.button1);

        //2. 버튼을 눌렀을때, 액션처리 셋팅
        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), CalActivity.class);
                startActivity(intent);
            }
        });
        //3. 액션처리 구체적인 내용
        //   cal 액티비티로 넘김




        //1. layout에 있던 버튼을 찾아서
        Button login =findViewById(R.id.button2);

        //2. 버튼을 눌렀을때, 액션처리 셋팅
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
        //3. 액션처리 구체적인 내용
        //   cal 액티비티로 넘김



        //1. layout에 있던 버튼을 찾아서
        Button ok =findViewById(R.id.button3);

        //2. 버튼을 눌렀을때, 액션처리 셋팅
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), OkActivity.class);
                startActivity(intent);
            }
        });
        //3. 액션처리 구체적인 내용
        //   cal 액티비티로 넘김


        //1. layout에 있던 버튼을 찾아서
        Button not =findViewById(R.id.button4);

        //2. 버튼을 눌렀을때, 액션처리 셋팅
        not.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), NotActivity.class);
                startActivity(intent);
            }
        });
        //3. 액션처리 구체적인 내용
        //   cal 액티비티로 넘김




    }
}
