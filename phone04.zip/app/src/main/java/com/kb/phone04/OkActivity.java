package com.kb.phone04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OkActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ok);



        //1. layout에 있던 버튼을 찾아서
        Button start1 =findViewById(R.id.start1);

        //2. 버튼을 눌렀을때, 액션처리 셋팅
        start1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
        //   cal 액티비티로 넘김
        //3. 액션처리 구체적인 내용



    }
}
