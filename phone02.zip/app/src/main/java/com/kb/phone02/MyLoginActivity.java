package com.kb.phone02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MyLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_login);


        EditText idText =findViewById(R.id.idText);
        EditText pwText =findViewById(R.id.pwText);

        String id=idText.getText().toString();
        String pw=pwText.getText().toString();


        String oriId="root";
        String oriPw="pass";

        if(id.equals(oriId) && pw.equals(oriPw)){
            Toast.makeText(getApplicationContext(), "로그인 성공, 메모장으로 이동함..", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(), "로그인 실패, 재로그인 요망..", Toast.LENGTH_SHORT).show();

        }

        Button login9=findViewById(R.id.login9);

        login9.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "나의 메모장으로 직접 화면 전환함...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(),MemoActivity.class);
            startActivity(intent);
        }
    });
    }


//






}
